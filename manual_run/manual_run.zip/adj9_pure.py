"""adj9_pure.py -- the Adjust adj9 signature in pure Python.  No VM.

THE WHOLE ALGORITHM
-------------------
    blob = header(16) || whitened_record(144) || digest(32)

  header   bionic rand(seeded by the signing second), 310 warm-up draws,
           then a pair-XOR.  A pure function of the second.

  record   144 bytes assembled field by field; build_record() lays them out.  The seed expands into d0/d2/d4 through a fixed
           permutation network.  The request fields are concatenated into the
           "claims" string in a fixed order: sorted profile keys, then the
           pinned adj_signing_id, then sorted tail keys, then the sdk block.
           A key is emitted only when the request actually carries it.

  block    record[46:78] = SHA-256 over
               D9 || 00 08 || head || LE32(seed) || sha256("") || 01 00*16
               || claims
           using standard padding and round constants but chained from IV2,
           a custom chaining value, instead of the standard SHA-256 IV.

  whitening  a 14-round SPN over the record's 9 chunks, CBC-chained from the
           header as IV:
               XOR round key -> AES S-box ^ 0x55 -> ShiftRows -> AES
               MixColumns -> final sweep.
           That is AES-256 with the S-box and the row permutation replaced, and
           a constant XOR'd around the S-box.  Only the 240-byte round-key
           schedule is a fixed value.

  digest    blob[160:192] = SHA-256( (K^opad) || opad || SHA-256(
           (K^ipad) || ipad || body ) ) -- a two-pass SHA-256 MAC, not
           standard HMAC (the raw pad block is hashed a second time).

Every one of these is byte-exact against the genuine captures and against the
FinEx VM itself; see ../adj9/rev/algo_practice/block_law2/LAW.md and
digest_law/LAW.md.

USAGE
-----
    import adj9_pure as S, json
    blob, second, info = S.sign_request(params, "session")
    header_value = S.authorization_header(blob)

FIXED PARAMETERS
----------------
Three values are inputs to the scheme rather than consequences of it, and
are simply stated here:

    IV2   32 B   the chaining value the block hash starts from
    K     32 B   the MAC key the digest is keyed with
    KB   240 B   the whitening round-key schedule

Everything else in this file is computed: the SHA-256 round constants come
from the cube roots of the first 64 primes, the SHA-256 IV from the square
roots of the first 8, the AES S-box from its own definition, and AES
MixColumns and ShiftRows are written out as arithmetic.

HANDLING THE SEED
-----------------
    sign_request() draws os.urandom(4) as the per-fill seed unless you pass
    seed=.  Two runs on identical inputs DIFFER.  Always pin it before any
    A/B comparison.
"""

from __future__ import annotations
import base64, datetime, hashlib, os, struct, time

# ------------------------------------------------------------------------
# DEFAULTS -- the fallbacks sign_request uses when campaign_data omits a key
# ------------------------------------------------------------------------

# The APK signing-certificate SHA-1 is the only per-app input, and it is not
# a constant here -- pass it in campaign_data["cert_sha1"].  The VM called it
# "descriptor 9"; it is simply the cert.

# THE HEAD PHASE: the prefix bytes of the d0 selector list.
#
# It is an input, and it does not affect attribution.  Measured all four
# combinations -- penti and creditsea each signed with (0x2b,) and with
# (0x2b,0x48) -- and every one joined to its own campaign, because the server
# does not verify the envelope.  So one value serves every app; a caller passes
# head_phase= only to reproduce a specific captured signature.
#
# It is NOT a per-app constant.  Six consecutive-second signings from ONE penti
# launch used (0x2b,) (0x2b,) (0x2b,0x48) (0x2b,0x48) (0x2b,0x48) (0x2b,).
# Nor is it derivable from anything visible: two of those are both
# activity_kind=session with every field identical, and a seed-bit search gives
# candidates a permutation test cannot separate from chance (p = 0.40).
#
# 0x2b = 43: the first selector byte every observed phase begins with.  A
# selector s selects the d4 halfwords whose bits are set in (s << 1) + 3, so
# 0x2b selects bits of mask 0x59.  The rest of the list is the generated
# cycle 0x40 | (i & 7) -- also selectors, not arbitrary data.
HEAD_PHASE_DEFAULT = (0x2B,)


# THE CLAIMS LAW -- which request fields get signed, and in what order
# ------------------------------------------------------------------------
# ONE law covers every SDK generation.  The key lists differ slightly between
# 5.7 and 5.8, but a key is emitted only when the request map actually
# carries it non-empty, so the union of both lists produces the same bytes as
# whichever list that SDK would have used on its own.
#
# A key enters in a fixed place: sorted within the profile group, then the
# pinned adj_signing_id, then sorted within the tail, then block2.

PROFILE = [
    'adj_verification', 'android_uuid', 'api_level', 'app_token',
    'app_version', 'country', 'created_at', 'device_name', 'device_type',
    'environment', 'gps_adid', 'gps_adid_src', 'hardware_name',
    'installed_at', 'os_build', 'os_name', 'os_version', 'package_name',
    'push_token',
]

# the event endpoint adds its own fields; solved from the genuine penti capture
# in adj9/cap/oracle_run3.log, 542-byte claims for that signing
EVENT_EXTRA = ['event_count', 'event_token', 'partner_params']

ATTR_DROP = ['hardware_name', 'installed_at', 'os_build']

ATTR_EXTRA = ['initiated_by']

# kind -> (profile keys, tail keys)
_GROUPS = {
    'session': (PROFILE + ['initiating_package_name'],
                ['session_count', 'session_length', 'store_name_from_system',
                 'subsession_count', 'time_spent', 'tracking_enabled',
                 'updated_at']),
    'click': (PROFILE + ['click_time', 'click_time_server',
                         'google_play_instant', 'install_begin_time',
                         'install_begin_time_server', 'install_version',
                         'referrer', 'referrer_api'],
              ['session_count', 'session_length', 'source', 'subsession_count',
               'time_spent', 'tracking_enabled', 'updated_at']),
    'attribution': ([k for k in PROFILE if k not in ATTR_DROP] + ATTR_EXTRA,
                    ['tracking_enabled']),
    # `seq` is a TAIL key for events, not a profile key: it lands between the
    # pinned adj_signing_id and session_count in the emitted order.
    'event': (PROFILE + EVENT_EXTRA,
              ['seq', 'session_count', 'session_length', 'subsession_count',
               'time_spent', 'tracking_enabled']),
}

BLOCK2 = ['activity_kind', 'client_sdk', 'headers_id', 'native_version']

PIN = 'adj_signing_id'


def desc10_keys(val, kind):
    """Emission order: sorted profile, then PIN, then sorted tail, then block2.
    Only keys the map actually carries are emitted."""
    try:
        profile, tail = _GROUPS[kind]
    except KeyError:
        raise ValueError('claims law known for kinds: %s (got %r)'
                         % (', '.join(sorted(_GROUPS)), kind))
    keys = [k for k in sorted(profile) if val.get(k)]
    keys.append(PIN)                      # emitted pinned; read or not
    keys += [k for k in sorted(tail) if val.get(k)]
    keys += [k for k in BLOCK2 if val.get(k)]
    return keys


def build_desc10(val, kind):
    """The unpadded claims string -- the signed fields, concatenated."""
    keys = desc10_keys(val, kind)
    missing = [k for k in keys if k != PIN and not val.get(k)]
    if missing:
        raise KeyError('claims law missing values: %s' % missing)
    return ''.join(val[k] if k == PIN else val[k] for k in keys).encode('latin1')


def claims_for_law(val, kind):
    """(padded #10 bytes, unpadded length) -- NUL-pad to a 4-byte multiple;
    the claims length is the UNPADDED length."""
    raw = build_desc10(val, kind)
    return raw + b"\x00" * (-len(raw) % 4), len(raw)


# both names kept so existing callers keep working; there is one law now
claims_for_law_58 = claims_for_law
_LAW_57 = claims_for_law

# ------------------------------------------------------------------------
# THE HEADER -- 16 bytes, a pure function of the signing second
# ------------------------------------------------------------------------

# bionic's rand() is the minimal-standard Lehmer generator in Schrage's form,
# so no 64-bit multiply is needed.  Every number below follows from a small
# number of named choices rather than being arbitrary:
#
#     M      = 2**31 - 1       the Mersenne-prime modulus
#     A      = 7**5 = 16807    the multiplier
#     Q, R   = M//A, M%A      = 127773, 2836 -- the Schrage split
#     DEGREE = 31             MINSTD's polynomial has degree 31, so the
#                             state is 31 words wide
#     TAPS   = (3, 0)         bionic combines r[3] and r[0]
#     WARMUP = 310            draws discarded before the first result
#     SEED   = 0x075BD924     the zero-state default, as rand() has for
#                             srand(0).  NOT the textbook MINSTD seed
#                             123456789, which is 0x075BCD15.
_MINSTD_M = (1 << 31) - 1
_MINSTD_A = 7 ** 5
_MINSTD_Q = _MINSTD_M // _MINSTD_A
_MINSTD_R = _MINSTD_M % _MINSTD_A
_MINSTD_DEGREE = 31
_MINSTD_TAPS = (3, 0)
_MINSTD_WARMUP = 310
_MINSTD_SEED = 0x075BD924


class Random3:
    """bionic's rand(): a Schrage-form MINSTD generator, 31 words of state."""

    __slots__ = ("state", "fwd", "back")

    def __init__(self, seed):
        deg = _MINSTD_DEGREE
        # the seed as a signed 31-bit word; rand() never starts from zero
        s0 = seed & _MASK32
        if s0 == 0:
            s0 = 1
        prev = s0 if s0 < _MINSTD_M else s0 - 2 ** 32
        self.state = [prev] + [0] * (deg - 1)
        for i in range(1, deg):
            # Schrage's trick: one multiply of at most 31 bits each way.
            # Division must TRUNCATE toward zero, not floor, or a negative
            # state word takes a different branch than the C original.
            if prev >= 0:
                hi, lo = divmod(prev, _MINSTD_Q)
            else:
                hi = -((-prev) // _MINSTD_Q)
                lo = prev - hi * _MINSTD_Q
            word = lo * _MINSTD_A - hi * _MINSTD_R
            if word < 0:
                word += _MINSTD_M
            prev = word
            self.state[i] = word
        self.fwd, self.back = _MINSTD_TAPS
        for _ in range(_MINSTD_WARMUP):
            self.next()

    def next(self):
        """One draw: the top 31 bits of r[fwd] + r[back]."""
        st = self.state
        v = (st[self.fwd] + st[self.back]) & _MASK32
        st[self.fwd] = v if v < _MINSTD_M else v - 2 ** 32
        self.fwd = (self.fwd + 1) % _MINSTD_DEGREE
        self.back = (self.back + 1) % _MINSTD_DEGREE
        return v >> 1


def make_header(unix_sec):
    """The 16-byte header: eight draws, XORed in pairs, written big-endian.

    A pure function of the signing second -- nothing else feeds it.
    """
    r = Random3(unix_sec)
    d = [r.next() for _ in range(8)]
    return b"".join(struct.pack(">I", d[2 * i] ^ d[2 * i + 1])
                   for i in range(4))


# ------------------------------------------------------------------------
# THE REGION -- the seed-derived words, materialised from the 32-bit seed S
# ------------------------------------------------------------------------

def _mask(n: int) -> int:
    """Keep the low n bits: x & ((1 << n) - 1)."""
    return (1 << n) - 1


# The region law works on 16-bit and 32-bit lanes, so it masks to those widths.
# Derived rather than written as hex so the width is the statement.
_MASK16 = _mask(16)
_MASK31 = _mask(31)
_MASK32 = _mask(32)
_M32 = _MASK32          # same value; used by the SHA-256 helpers below

# The d0 head phase: the ONLY per-app input to the region law.  Short selector
# prefixes observed in real signatures; see HEAD_PHASE_DEFAULT above for what
# is and is not known about how the choice is made.
#
# Nothing else about d0 is stored.  Past the head prefix the selector list is
# generated as 0x40 | (i & 7); there are no selector tables here.
def _step(x: int) -> int:
    """One step of the Schrage-form MINSTD PRNG used by the header."""
    if x == 0:
        x = _MINSTD_SEED
    hi, lo = divmod(x, _MINSTD_Q)
    y = lo * _MINSTD_A - hi * _MINSTD_R
    if y < 0:
        y += _MINSTD_M
    return y & _MINSTD_M

def _raw16(seed: int) -> list[int]:
    """Shuffle (0x143c88) + pair consumption (0x1439c4) -> 16 pre-transpose halfwords.

    Not Fisher-Yates: the native buffer starts as 16 zero bytes and each draw
    swaps `perm[i]` with `perm[j]`, `j = r % (i + 1)`.  Even output indices take
    the high 16 bits of the state, odd indices the full low-32 value; bit
    position is `15 - perm[i]` with the low bits below it retained.
    """
    state = seed & _MASK32
    perm = [0] * 16
    for i in range(16):
        r = _step(state)
        state = r
        j = r % (i + 1)
        perm[i], perm[j] = perm[j], i

    pre = []
    for i in range(16):
        if (i & 1) == 0:
            state = _step(state)
        r = state
        v = (r >> 16) & _MASK16 if (i & 1) == 0 else r
        pos = 15 - perm[i]
        pre.append(((v & ((1 << pos) - 1)) | (1 << pos)) & _MASK16)
    return pre

def _transpose16(pre: list[int]) -> list[int]:
    """The 16x16 bit-matrix transpose at 0x143d98."""
    out = [0] * 16
    for j in range(16):
        v = 0
        for i in range(16):
            if pre[i] & (1 << (15 - j)):
                v |= 1 << (15 - i)
        out[j] = v
    return out

def _d4_words(seed: int) -> list[int]:
    """Descriptor #4: 8 big-endian words from the little-endian halfword stream."""
    raw = _transpose16(_raw16(seed))
    packed = b"".join(x.to_bytes(2, "little") for x in raw)
    return [int.from_bytes(packed[i:i + 4], "big") for i in range(0, 32, 4)]

def _d0_source(d4: list[int]) -> list[int]:
    """The eight halfwords of the second word-group that feed the selectors."""
    d4_bytes = b"".join(word.to_bytes(4, "big") for word in d4)
    return [int.from_bytes(d4_bytes[i:i + 2], "little") for i in range(16, 32, 2)]

def _selector_halfword(mask: int, source: list[int]) -> int:
    """XOR the source halfwords one 8-bit selector mask picks out."""
    value = 0
    for bit in range(8):
        if (mask >> bit) & 1:
            value ^= source[7 - bit]
    return value & _MASK16

def _d0_words(d4: list[int], head=None) -> list[int]:
    """Descriptor #0: 36 big-endian words, including the separate W0/X prefix.

    Entirely a formula -- there are no stored selector tables.  `head` is the
    per-app selector prefix (1-2 bytes); past it the selector list is the
    generated cycle 0x40 | (i & 7).  Each selector is folded into the d4
    halfwords by XOR, which is where all the seed dependence enters.

    The phase does not affect attribution; HEAD_PHASE_DEFAULT is fine for a
    live request.  Pass head= only to reproduce a captured signature.
    """
    source = _d0_source(d4)
    real_head = HEAD_PHASE_DEFAULT if head is None else tuple(head)
    selectors = tuple(real_head[i] if i < len(real_head) else (0x40 | (i & 7))
                      for i in range(72))
    values = [_selector_halfword((selector << 1) + 3, source)
              for selector in selectors]
    raw = b"".join(value.to_bytes(2, "little") for value in values)
    return [int.from_bytes(raw[i:i + 4], "big") for i in range(0, 144, 4)]

def region(V: int, pid: int, tid: int = 0, head=None):
    """The seed's three derived word-groups, in the VM's d0/d2/d4 naming.

    NOT on the signing path.  Signing needs only head16_for(seed, head) and
    the seed itself; this exists because the gates use it to recover the head
    phase from a captured signature, and because it is how the descriptors
    were originally described.

    V   : tv_sec ^ tv_usec at the fill instant (< 2**32)
    pid : process id; only the low 16 bits reach the seed
    tid : accepted for the contract, provably unused
    head: the d0 selector phase (see _d0_words)
    """
    del tid  # verified absent from the d0/d2 materializer and the d4 path
    seed = ((V & _MASK32) ^ ((pid & _MASK16) << 16)) & _MASK32
    d4 = _d4_words(seed)
    d0 = _d0_words(d4, head=head)
    # d2 is the little-endian store of the seed, read back as a BE word.
    d2 = int.from_bytes(seed.to_bytes(4, "little"), "big")
    return d0, d2, d4

def head_words(d0w):
    """The first four d0 words -> the 16 head bytes.

    Not on the signing path -- head16_for computes those bytes directly.  The
    gates use this to recover the head from a captured signature, because
    region() still exposes the descriptor triple.
    """
    return b"".join(struct.pack("<I", ((w & 0xFFFF) << 16) | (w >> 16))
                    for w in d0w[:4])


def head16_for(seed, head=None):
    """The 16-byte head the record carries, for a seed and a selector phase.

    Only 16 of the region's 144 bytes ever reach the record -- verified by
    zeroing d0[16:144] and getting a byte-identical blob -- so this goes
    straight from the seed to those 16 bytes.

    The chain is:  24 draws from the Lehmer generator -> a Fisher-Yates
    shuffle over 16 slots -> each halfword gets one bit forced at position
    15 - perm[i] -> the eight selector halfwords are folded out of them.

    This drops the word packing and the 16-bit swap that the long form
    (_d4_words -> _d0_source -> _d0_words -> head_words) applied and then
    undid.  verify_region_short.py checks it against that long form.
    """
    phase = HEAD_PHASE_DEFAULT if head is None else tuple(head)
    source = _transpose16(_raw16(seed))[8:16]
    selectors = [phase[a] if a < len(phase) else (0x40 | (a & 7))
                 for a in range(8)]
    return b"".join(_selector_halfword((s << 1) + 3, source).to_bytes(2, "big")
                    for s in selectors)

# ------------------------------------------------------------------------
# SHA-256 -- the standard round constants, derived from the primes
# ------------------------------------------------------------------------

SHA0 = hashlib.sha256(b"").digest()

def _rotr(x, n):
    return ((x >> n) | (x << (32 - n))) & _M32

def _compress(st, blk):
    w = list(blk)
    for i in range(16, 64):
        s0 = _rotr(w[i - 15], 7) ^ _rotr(w[i - 15], 18) ^ (w[i - 15] >> 3)
        s1 = _rotr(w[i - 2], 17) ^ _rotr(w[i - 2], 19) ^ (w[i - 2] >> 10)
        w.append((w[i - 16] + s0 + w[i - 7] + s1) & _M32)
    a, b, c, d, e, f, g, h = st
    for i in range(64):
        S1 = _rotr(e, 6) ^ _rotr(e, 11) ^ _rotr(e, 25)
        t1 = (h + S1 + ((e & f) ^ (~e & g)) + _K256[i] + w[i]) & _M32
        S0 = _rotr(a, 2) ^ _rotr(a, 13) ^ _rotr(a, 22)
        t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) & _M32
        h, g, f, e, d, c, b, a = (g, f, e, (d + t1) & _M32, c, b, a,
                                  (t1 + t2) & _M32)
    return [(x + y) & _M32 for x, y in zip(st, (a, b, c, d, e, f, g, h))]

def _primes(n):
    """The first n primes."""
    out, i = [], 2
    while len(out) < n:
        if all(i % p for p in out if p * p <= i):
            out.append(i)
        i += 1
    return out


def _frac_icbrt_scaled(p, scale=1 << 32):
    """floor( frac(cbrt(p)) * scale ) in exact integer arithmetic.

    k = floor(cbrt(p)); we want the largest m with (k + m/scale)^3 <= p,
    i.e. (k*scale + m)^3 <= p*scale^3.  No floating point is involved, so
    there is no rounding to argue about.
    """
    k = 0
    while (k + 1) ** 3 <= p:
        k += 1
    target = p * scale ** 3
    base = k * scale
    lo, hi = 0, scale
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if (base + mid) ** 3 <= target:
            lo = mid
        else:
            hi = mid - 1
    return lo


# The SHA-256 round constants are DERIVED, not stored:  FIPS 180-4 defines
# them as the first 32 bits of the fractional parts of the cube roots of the
# first 64 primes.  Nothing here is Adjust-specific.
#
#     _K256[i] = floor( frac(cbrt(p_i)) * 2^32 )
#
# verify_K256_law.py checks this derivation two ways (exact integers, and
# 60-digit Decimal cube roots) and confirms it equals the published table.
_K256 = tuple(_frac_icbrt_scaled(p) for p in _primes(64))


def _frac_isqrt_scaled(p, scale=1 << 32):
    """floor( frac(sqrt(p)) * scale ), exact integers, no floats."""
    n = 0
    while (n + 1) ** 2 <= p:
        n += 1
    target, base = p * scale ** 2, n * scale
    lo, hi = 0, scale
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if (base + mid) ** 2 <= target:
            lo = mid
        else:
            hi = mid - 1
    return lo


# the standard SHA-256 IV, for comparison: square roots of the first 8 primes
_SHA256_IV = tuple(_frac_isqrt_scaled(p) for p in _primes(8))

# ------------------------------------------------------------------------
# THE BLOCK -- record[46:78], SHA-256 chained from the VM's IV2
# ------------------------------------------------------------------------

# The block law's chaining value.  Not a SHA-256 IV: SHA-256 chains from
# 6a09e667..., this chains from this instead.  Everything else about the hash
# -- padding, round constants -- is standard.
_BLK_IV2 = bytes.fromhex("eba2c4350f4002dc9fa8dac5127035ba"
                         "7a30ed9323473054bbe3cd00f1355ea5")

def _sha256_iv2(msg):
    st = list(struct.unpack(">8I", _BLK_IV2))
    m = (msg + b"\x80" + b"\x00" * ((55 - len(msg)) % 64)
         + struct.pack(">Q", len(msg) * 8))
    for i in range(0, len(m), 64):
        st = _compress(st, [int.from_bytes(m[i + 4 * j:i + 4 * j + 4], "big")
                            for j in range(16)])
    return struct.pack(">8I", *st)

def _predict_block(head_b, seed, claims, d9):
    """record[46:78) = SHA256-IV2( D9 || 00 08 || head || LE32(S)
                                 || sha256("") || 01 00*16 || claims )"""
    msg = (d9 + b"\x00\x08" + head_b + struct.pack("<I", seed)
           + SHA0 + b"\x01" + b"\x00" * 16 + claims)
    return _sha256_iv2(msg)

# ------------------------------------------------------------------------
# THE DIGEST -- blob[160:192], a two-pass SHA-256 MAC
# ------------------------------------------------------------------------

# The digest law's MAC key.
_DIG_K = bytes.fromhex("690f60944dddd9847db55cd7d2d576b3"
                       "0451723fbcfa92df62b55f6fec60f2de")

_DIG_IPAD = b"\x36" * 32

_DIG_OPAD = b"\x5c" * 32

_DIG_KI = bytes(a ^ b for a, b in zip(_DIG_K, _DIG_IPAD))

_DIG_KO = bytes(a ^ b for a, b in zip(_DIG_K, _DIG_OPAD))

def _predict_digest(body):
    inner = hashlib.sha256(_DIG_KI + _DIG_IPAD + body).digest()
    return hashlib.sha256(_DIG_KO + _DIG_OPAD + inner).digest()

# ------------------------------------------------------------------------
# THE WHITENING CIPHER -- AES-256 with the S-box, ShiftRows and
# ------------------------------------------------------------------------

# ------------------------------------------------------------------------
#      a fixed key replaced; only the round keys are recorded
# ------------------------------------------------------------------------


# PI is AES ShiftRows: treat the chunk as a 4x4 state (byte i is row i%4,
# column i//4) and rotate each row r left by r.
# _pi1 does out[PI[i]] = in[i];  _pi1_inv does out[j] = in[PI_INV[j]].
PI_INV = [4 * (((j // 4) + (j % 4)) % 4) + (j % 4) for j in range(16)]
PI = [4 * (((i // 4) - (i % 4)) % 4) + (i % 4) for i in range(16)]

def _gmul(a, b):
    """Multiply in GF(2^8) mod the AES polynomial 0x11B."""
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        a = ((a << 1) ^ 0x1B) & 0xFF if a & 0x80 else (a << 1) & 0xFF
        b >>= 1
    return p

def _gpow(a, e):
    """a^e in GF(2^8)."""
    r, base = 1, a
    while e:
        if e & 1:
            r = _gmul(r, base)
        base = _gmul(base, base)
        e >>= 1
    return r

def _rotl8(x, n):
    n %= 8
    return ((x << n) | (x >> (8 - n))) & 0xFF

def _aes_sbox():
    """The standard AES S-box, built from its definition rather than stored:
    S(x) = L(x^-1) ^ 0x63 over GF(2^8) mod 0x11B, L the AES affine map."""
    return [(lambda iv: iv ^ _rotl8(iv, 1) ^ _rotl8(iv, 2) ^ _rotl8(iv, 3)
             ^ _rotl8(iv, 4) ^ 0x63)(0 if v == 0 else _gpow(v, 254))
            for v in range(256)]

_BYTE_MSBS = 0x80808080     # each byte's top bit -- the bit xtime may carry out
_BYTE_NOHI = 0xFEFEFEFE     # clears those bits, keeping the shifted bytes


def _xt(x):
    """Branch-free bytewise xtime over a whole 32-bit word: multiply every
    byte by 2 in GF(2^8) mod 0x11B, in one go."""
    m = x & _BYTE_MSBS
    return ((x << 1) & _BYTE_NOHI) ^ (((m >> 7) * 0x1B) & _MASK32)

def F_word_fast(x):
    """AES MixColumns -- F IS MixColumns, not merely AES-shaped.

        y_b = 2*x_b ^ 3*x_(b+1) ^ x_(b+2) ^ x_(b+3)      byte indices mod 4

    Written as 3*z = 2*z ^ z over the byte-rotated z = x rotated right one
    byte, so the whole thing is word arithmetic with no per-byte loop.

    Written branch-free so it costs one pass over four 32-bit words.
    """
    z = ((x >> 8) | (x << 24)) & _MASK32        # rotate right one byte
    return (_xt(x ^ z) ^ z                         # 2*(x^z) ^ z  == 2x ^ 3z
            ^ ((x >> 16) | (x << 16))              # bytes +2
            ^ ((x >> 24) | (x << 8))) & _MASK32  # bytes +3

def F_word_inv_fast(y):
    """AES InvMixColumns -- the inverse circulant [14, 11, 13, 9].

        v_b = 14*b_b ^ 11*b_(b+1) ^ 13*b_(b+2) ^ 9*b_(b+3)
    """
    b = [(y >> (8 * i)) & 0xFF for i in range(4)]
    out = 0
    for i in range(4):
        v = (_gmul(14, b[i]) ^ _gmul(11, b[(i + 1) % 4])
             ^ _gmul(13, b[(i + 2) % 4]) ^ _gmul(9, b[(i + 3) % 4]))
        out |= v << (8 * i)
    return out

def _F(chunk):
    return b"".join(F_word_fast(int.from_bytes(chunk[4 * b:4 * b + 4],
                                             "little")).to_bytes(4, "little")
                    for b in range(4))

def _F_inv(chunk):
    return b"".join(F_word_inv_fast(int.from_bytes(chunk[4 * b:4 * b + 4],
                                                 "little")).to_bytes(4, "little")
                    for b in range(4))

def _pi1(chunk):
    out = bytearray(16)
    for i in range(16):
        out[PI[i]] = chunk[i]
    return bytes(out)

def _pi1_inv(chunk):
    # undo out[PI[i]] = in[i]  ->  in[i] = out[PI[i]]
    return bytes(chunk[PI[i]] for i in range(16))

T = bytes(v ^ 0x55 for v in _aes_sbox())

T_INV = [0] * 256
for _x, _v in enumerate(T):
    T_INV[_v] = _x

# The whitening cipher's round-key schedule: 15 keys x 16 bytes, one per
# round, with a 14th-round final sweep.  Fixed for a given libsigner build and
# identical across every app; it is not derived from any other input.
KB = bytes.fromhex(
    "43fc368804c8ed1b17e5c8f603002f469e8f7ca2b2713e088c3f18324e1bc304"
    "6d6ce7273cf15f697e41c2ca2814b8d9610c29c68628429b5f420ffc440c99ad"
    "a427a6a5cd83ac99e6973b069bd6d68aeae0c558399dd296338a883f22d344c7"
    "e4a5e9507c73109ccfb17ecf0132fd10ca650736a6ad80f5c0725d9fb7f44c0d"
    "de7183c8f757c6016db3ed9b39d445de9a69cd0b699118abfcb610611e170939"
    "e23bd37b4039402f78dff8e1145ee86a1942b77e2586fa808c65bfb4c727e3d8"
    "82758e3497199b4eba9336fafb988bc5fdffaa1e8d2c05cb541cef2ac66e59a7"
    "208b07e8e2c7c9f30d01aa5ca3cc74cc")

def whiten_chunk(chunk, WA, _kb=KB):
    """One forward chunk: 14 rounds + final sweep.  (chunk ^ WA is inside.)"""
    x = bytearray(a ^ b for a, b in zip(chunk, WA))
    for r in range(14):
        x = bytearray(v ^ 0x55 ^ _kb[16 * r + i] for i, v in enumerate(x))
        x = bytearray(T[v] ^ 0x55 for v in x)
        x = bytearray(_pi1(bytes(x)))
        if r < 13:
            x = bytearray(_F(bytes(x)))
    return bytes(v ^ 0x55 ^ _kb[224 + i] for i, v in enumerate(x))

def whiten_forward(record, header):
    """record: 144 B plaintext, header: 16 B IV -> whitened body (144 B)."""
    out = bytearray()
    wa = header
    for k in range(len(record) // 16):
        c = whiten_chunk(record[16 * k:16 * k + 16], wa)
        out += c
        wa = c
    return bytes(out)

def whiten_inverse(chunk, WA, KB_=None, T_inv=None, pi1_inv=None, F_inv=None):
    """Invert one whitened 16-B chunk given its WA (previous chunk final, or
    the header for chunk 0).  Returns the recovered 16-B plaintext chunk.

    KB_      : 240-B key table            (default: extracted KB)
    T_inv    : 256-entry inverse S-box    (default: extracted T_INV)
    pi1_inv  : inverse byte permutation   (default: extracted PI_INV);
               must satisfy pi1_inv(pi1(x)) == x
    F_inv    : callable 16 B -> 16 B inverting the diag-2 map (default _F_inv)
    """
    kb = KB if KB_ is None else KB_
    tinv = T_INV if T_inv is None else T_inv
    pinv = _pi1_inv if pi1_inv is None else pi1_inv
    finv = _F_inv if F_inv is None else F_inv
    x = bytes(v ^ 0x55 ^ kb[224 + i] for i, v in enumerate(chunk))  # final sweep
    for r in range(13, -1, -1):
        if r < 13:
            x = finv(x)                       # undo diag-2 affine
        x = pinv(x)                           # undo diag-1 permutation
        x = bytes(tinv[v ^ 0x55] for v in x)  # undo S-box
        x = bytes(v ^ 0x55 ^ kb[16 * r + i] for i, v in enumerate(x))
    return bytes(a ^ b for a, b in zip(x, WA))  # remove the WA XOR

def whiten_body_inverse(body, header, KB_=None, T_inv=None, pi1_inv=None,
                        F_inv=None):
    """body: 144 whitened bytes (blob[16:160)), header: blob[0:16).
    Returns the 144-B record."""
    out = bytearray()
    wa = header
    for k in range(len(body) // 16):
        p = whiten_inverse(body[16 * k:16 * k + 16], wa, KB_, T_inv,
                           pi1_inv, F_inv)
        out += p
        wa = body[16 * k:16 * k + 16]
    return bytes(out)

# ------------------------------------------------------------------------
# THE RECORD -- 144 bytes, assembled field by field, then encrypted
# ------------------------------------------------------------------------

def build_record(seed, head, claims, cert):
    """The 144-byte plaintext record, laid out field by field.

    seed   32-bit fill seed; supplies the seed word and, through the region
           law, the head
    head   the 16-byte region head
    claims the claims string, UNPADDED
    cert   the APK certificate SHA-1 (20 bytes)

    The layout is tag-delimited: a one-byte tag precedes each variable field.
    Only two fields are computed -- the head (from the region law) and the
    block (a hash of the other three).  Everything else is fixed format.
    """
    head, cert = bytes(head), bytes(cert)
    if len(head) != 16:
        raise ValueError("head must be 16 bytes, got %d" % len(head))
    if len(cert) != 20:
        raise ValueError("cert must be 20 bytes, got %d" % len(cert))
    rec = bytearray(144)
    rec[0:3] = b"\x01\x00\x08"
    rec[3:19] = head                                # region head
    rec[19] = 0x02
    rec[20:24] = struct.pack(">I", seed)            # the seed
    rec[24] = 0x03
    rec[25:45] = cert                               # APK cert SHA-1
    rec[45] = 0x04
    rec[46:78] = _predict_block(head, seed, claims, cert)
    rec[78] = 0x05
    rec[79:111] = SHA0                              # sha256("")
    rec[111:114] = b"\x06\x01\x07"
    rec[114:128] = b"\x00" * 14
    rec[128:130] = b"\x00" * 2
    rec[130:144] = b"\x0e" * 14
    return bytes(rec)


def sign(second, seed, claims, d9, head=None):
    """The 192-byte signature.  A pure function of its five arguments.

    second : the signing second -> the 16-byte header
    seed   : the 32-bit fill seed -> d0/d2/d4
    claims : the descriptor-#10 claims string, unpadded
    d9     : the APK certificate SHA-1
    head   : the d0 selector phase for this request
    """
    head16 = head16_for(seed, head)
    record = build_record(seed, head16, claims, d9)
    header = make_header(int(second))
    body = whiten_forward(record, header)
    return header + body + _predict_digest(body)


def sign_request(params, kind, campaign_data, head=None, second=None,
                 seed=None):
    """Sign one request.  -> (authorization_header_value, blob_192B)

    The header value is what you send; the blob is here for callers that want
    to inspect the bytes (the verification gates do).

    A pure function of its arguments -- nothing is remembered between calls,
    so signing for two apps needs no setup and cannot leak into each other.

    params        the request's own fields
    kind          session | click | attribution | event
    campaign_data this app's settings.  The keys that reach the signature:
                      cert_sha1        the APK signing-certificate SHA-1
                      client_sdk       Flutter apps use a composite value like
                                       "flutter5.8.0@android5.8.0", not the
                                       bare SDK version
                      adj_signing_id   a pinned claim (default "1500000")
                      headers_id       (default "10")
                      native_version   (default "5.0.0")
                      adj_verification
                      head_phase       optional; the d0 selector prefix.  It
                                       does not affect attribution (measured
                                       both ways for two apps) and exists only
                                       to reproduce a captured signature.

    seed=None draws os.urandom(4) -- pin it for any A/B comparison.
    """
    c = campaign_data
    val = dict(params)
    val.update({"activity_kind": kind,
                "client_sdk": c.get("client_sdk", "android5.7.0"),
                "adj_signing_id": c.get("adj_signing_id", "1500000"),
                "headers_id": c.get("headers_id", "10"),
                "native_version": c.get("native_version", "5.0.0"),
                "adj_verification": c.get("adj_verification", "")})
    second = int(second if second is not None else time.time())
    seed = int.from_bytes(os.urandom(4), "big") if seed is None else seed
    if not c.get("cert_sha1"):
        raise ValueError("campaign_data needs a cert_sha1")
    padded, unpadded_len = claims_for_law(val, kind)
    # the block law hashes the claims UNPADDED: strip the NUL padding back off
    blob = sign(second, seed, padded[:unpadded_len],
                bytes.fromhex(c["cert_sha1"]),
                head or c.get("head_phase") or HEAD_PHASE_DEFAULT)
    return authorization_header(blob, campaign_data), blob


def authorization_header(blob, campaign_data):
    """The envelope -> the value for the Authorization header.

    campaign_data is the same dict passed to sign_request; it supplies the
    three pinned values the header carries.

    The server does not verify this envelope on the join path, but it must be
    well formed for the request to be accepted at all.
    """
    c = campaign_data
    return ('Signature signature="%s",adj_signing_id="%s",algorithm="adj9",'
            'headers_id="%s",native_version="%s",adj_verification="%s"'
            % (base64.b64encode(blob).decode(),
               c.get("adj_signing_id", "1500000"),
               c.get("headers_id", "10"),
               c.get("native_version", "5.0.0"),
               c.get("adj_verification", "")))
